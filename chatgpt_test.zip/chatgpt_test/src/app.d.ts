/*
 * @Author: foxfly
 * @Contact: 617903352@qq.com
 * @Date: 2023-09-01 15:18:23
 * @Description: 全局类型声明文件
 */
declare module '*.png';
declare module '*.jpeg';
