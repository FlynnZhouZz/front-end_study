/*
 * @Author: foxfly
 * @Contact: 617903352@qq.com
 * @Date: 2024-04-17 16:23:09
 * @Description: 配置文件
 */

/** storage key */
export const storageKey = 'OPENROUTERKEY';

