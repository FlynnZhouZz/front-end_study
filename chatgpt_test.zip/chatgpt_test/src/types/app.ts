/*
 * @Author: foxfly
 * @Contact: 617903352@qq.com
 * @Date: 2024-04-17 16:24:00
 * @Description: @/pages/App 类型声明
 */

export {};
